/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SpellChecker;


/**
 *
 * @author duaqadeer
 */
public class BKNode {
    public String word;
    public String meaning;
    public BKNode[] next;
    final int LEN=40;
    public BKNode(String w, String m){
        word=w;
        meaning=m;
        next = new BKNode[LEN];
    }
    public String showWord(){
        return word;
        
    }
    public String showmeaning(){
        return meaning;
        
    }
}
