/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SpellChecker;

/**
 *
 * @author duaqadeer
 */
public class ListQueue {
    public QNode Front;
    public QNode Rear;
    public int nodes;
    public ListQueue(){
        nodes=0;
    }
    public void Enqueue(String s){
        nodes++;
        QNode newnode = new QNode(s);
        if(this.isEmpty()){
            Front = newnode;
            Rear = newnode;
        }
        else{
            Rear.next=newnode;
            Rear=Rear.next;
        }
    }
    public String Dequeue(){
        if(this.isEmpty()){
            System.out.println("Queue is empty");
            return null;
        }
        else{
            nodes--;
            QNode temp =Front;
            Front=Front.next;
            return  temp.data;
        }
    }
    public boolean isEmpty(){
        return Front==null;
    }
    @Override
    public String toString(){
        if(this.isEmpty()){
            return "Queue is empty";
        }
        String s="";
        QNode temp=Front;
        while(temp!=Rear){
            s+=temp + " ";
            temp= temp.next;
        }
        s+= temp;
        return s;
    }
}
