/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SpellChecker;


/**
 *
 * @author duaqadeer
 */
public class BKTree {

    public BKNode root;
    int TOL;
    private void setTol(int t){
        TOL=t;
    }
    public void Insert(BKNode node, BKNode r){
        if(r==null){
            root=node;
            return;
        }
        int index = getLevenShteinDistance(node.word,r.word) -1;
        if (index==-1){
            //System.out.println("this word is already in tree");
            return;
        }
        BKNode n = r.next[index];
        if(n==null){
            r.next[index]=node;
        }
        else{
            Insert(node, n);
        }
    }
    public ListQueue FindSuggestions(String s,BKNode R){
        ListQueue WordsList = new ListQueue();
        if(R==null)
            return WordsList;
        int dis = getLevenShteinDistance(s,R.word);
        if(dis<=TOL)
            WordsList.Enqueue(R.word);
        int initial=dis-TOL;
        if(initial<0)
            initial=1;
        while(initial<=dis+TOL){
            ListQueue temp= FindSuggestions(s,R.next[initial]);
            if(temp!=null){
                for(int i=0;i<temp.nodes;i++){
                    WordsList.Enqueue(temp.Dequeue());
                }   
            }
            initial++;
        }
        return WordsList;
        
    }
    public ListQueue Find(String s, BKNode R){
        while(R!=null){
           int dist=getLevenShteinDistance(s,R.word)-1;
           if(dist==-1)
               return null;
           R= R.next[dist];
        }
        if(s.length()<=5)
            setTol(1);
        else
            setTol(2);
        return FindSuggestions(s,root);
    }
     public int getLevenShteinDistance(String s1, String s2) {
        int l1= s1.length();
        int l2= s2.length();
        int[][] table = new int[l1+1][l2+1];
        for (int i = 0; i <= s1.length(); i++) {
        for (int j = 0; j <= s2.length(); j++) {
            if (i == 0) {
                table[i][j] = j;
            }
            else if (j == 0) {
                table[i][j] = i;
            }
            else {
                int replace= table[i - 1][j - 1];
                int insert= table[i][j - 1];
                int delete = table[i - 1][j];
                table[i][j]= Math.min(replace + Replacement_distance(s1.charAt(i - 1), s2.charAt(j - 1)), Math.min(delete+1,insert+1));
            }
        }
    }
        
    return table[l1][l2];
}
    private static int Replacement_distance(char char1, char char2) {
         if(char1==char2)
            return 0;
        else
            return 1;
    }
    public static void main(String[] args){
        BKTree tree = new BKTree();
        System.out.println("distance: "+tree.getLevenShteinDistance("rot","boot"));
       
    }
}

