/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SpellChecker;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author duaqadeer
 */
public class DS_FinalProject {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        BKTree tree = new BKTree();
        int count=0;
        try {
            File dictionary = new File("New_Dictionary.txt");
            Scanner sc = new Scanner(dictionary);
            while(sc.hasNextLine()){
                String line = sc.nextLine();
                if(!line.isBlank()){
                String[] split= line.split("  ");
                if(split.length==2){
                    count++;
                    BKNode n = new BKNode(split[0].toLowerCase(),split[1]);
                    //System.out.println(n.word);
                    tree.Insert(n,tree.root);
                }
            }
        }
            sc.close();
        }catch (FileNotFoundException ex) {
            System.out.println("No file present");
        }
        System.out.println(count);
        System.out.println(tree.Find("boat", tree.root));
        System.out.println(tree.Find("call", tree.root));
    }
    
}
    




























