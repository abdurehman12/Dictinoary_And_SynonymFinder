/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SpellChecker;

/**
 *
 * @author duaqadeer
 */

public class QNode {
    public String data;
    public QNode next;
    public QNode(String d){ // BigO = O(1)
        data=d;
    }
    @Override
    public String toString(){
        return data;
    }
}

