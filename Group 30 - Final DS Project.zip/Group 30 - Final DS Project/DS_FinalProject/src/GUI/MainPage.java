/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package GUI;

import SpellChecker.BKNode;
import SpellChecker.BKTree;
import SpellChecker.ListQueue;
import SpellChecker.QNode;
import Synonyms.SynonymsGraph;
import java.awt.Component;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;

/**
 *
 * @author dell
 */
public class MainPage extends javax.swing.JFrame{
    
    /**
     * Creates new form 
     */
    BKTree tree=new BKTree();
    SynonymsGraph graph = new SynonymsGraph();
    DefaultListModel defaultListModel=new DefaultListModel();
    private Component rootPane;
    
    public MainPage() {
        getword();
        getsynonyms();
        initComponents();
        this.bindData();
    }
    
    private void getword(){   //thats how we are storing the word 
      int count =0; 
    try{
        File dictionary = new File("New_Dictionary.txt");
            Scanner sc = new Scanner(dictionary);
            while(sc.hasNextLine()){
                String line = sc.nextLine();
                if(!line.isBlank()){
                String[] split= line.split("  ");
                if(split.length==2){
                    count++;
                    BKNode n = new BKNode(split[0].toLowerCase(),split[1]);
                    tree.Insert(n,tree.root);
                }
            }
        }
            sc.close();
        }catch (FileNotFoundException ex) {
            System.out.println("No file present");
        }
   }
    private void bindData(){ 
        
         jList1.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    }
    public void findmeaning(String s, BKNode W){
        DefaultListModel filteredItems =new DefaultListModel();
        int d;
        while(W!=null){
            d=tree.getLevenShteinDistance(s,W.word)-1;
            if (d==-1){
                String s1=W.meaning;
                String[] split = s1.split("—v.");
                if(split.length>0){
                    for(int i=0; i<split.length;i++){
                        filteredItems.addElement(split[i]);
                    }
                }
                else{
                    filteredItems.addElement(W.meaning);
                }
                String syn = graph.FindVertex(s).toString();
                
                String[] sep = syn.split(", ");
                if(sep.length>0){
                    filteredItems.addElement(W.word+"\n has synonyms:");
                    for(int i=0; i<sep.length;i++){
                        filteredItems.addElement(sep[i]);
                    }
                }
                else{
                    filteredItems.addElement(graph.FindVertex(s));
                }
            }
            W=W.next[d]; 
            defaultListModel=filteredItems;
            jList1.setModel(defaultListModel);
             
        }
    }
    public void searchfilter(String searchTerm){
        DefaultListModel filteredItems =new DefaultListModel(); // filtered items holding, means listqueue after find
        ListQueue q =tree.Find(searchTerm,tree.root);
        QNode temp = q.Front;
        while(temp!=null){
            filteredItems.addElement(temp.data);
            temp=temp.next;
        }
        defaultListModel=filteredItems;
        jList1.setModel(defaultListModel);
    }
    private void getsynonyms(){
        try{
            File synonyms = new File("SynonymsList1.txt");
            Scanner sc = new Scanner(synonyms);
            while(sc.hasNextLine()){
                String line = sc.nextLine();
                if(!line.isBlank()){
                    line=line.toLowerCase();
                    String[] split=line.split(" — ");  
                        String[] syn = split[1].split(", ");
                        graph.AddVertex(split[0]);
                        for(int i=0; i<syn.length;i++){
                            graph.AddVertex(syn[i]);
                            graph.AddEdge(split[0], syn[i]);
                            for(int j=0;j<syn.length-1;){
                                if(j!=i){
                                    graph.AddEdge(syn[i],syn[j]);
                                    graph.AddEdge(syn[j], split[0]);
                                }
                                j++;
                            }
                        }
                }
            }
        synonyms = new File("SynonymsList2.txt");
        sc= new Scanner(synonyms);
            while(sc.hasNextLine()){
                String line = sc.nextLine();
                if(!line.isBlank()){
                    line=line.toLowerCase();
                    String[] split=line.split(" – ");  
                    if(split[1].contains(",")){
                        String[] syn = split[1].split(", ");
                        graph.AddVertex(split[0]);
                        for(int i=0; i<syn.length;i++){
                            graph.AddVertex(syn[i]);
                            graph.AddEdge(split[0], syn[i]);
                            for(int j=0;j<syn.length-1;){
                                if(j!=i){
                                    graph.AddEdge(syn[i],syn[j]);
                                    graph.AddEdge(syn[j], split[0]);
                                }
                                j++;
                            }
                        }
                    }
                    else{
                        graph.AddVertex(split[0]);
                        graph.AddVertex(split[1]);
                        graph.AddEdge(split[0], split[1]);
                    }
                }
            }
            synonyms = new File("SynonymsList3.txt");
            sc= new Scanner(synonyms);
            while(sc.hasNextLine()){
                String line = sc.nextLine();
                if(!line.isBlank()){
                    line=line.toLowerCase();
                    String[] split=line.split(" . ");  
                    graph.AddVertex(split[0]);
                    graph.AddVertex(split[1]);
                    graph.AddEdge(split[0], split[1]);
                }
            }
            synonyms = new File("SynonymsList4.txt");
            sc= new Scanner(synonyms);
            while(sc.hasNextLine()){
                String line = sc.nextLine();
                if(!line.isBlank()){
                    line=line.toLowerCase();
                    String[] split=line.split(" . ");
                    if(split[1].contains(",")){
                        String[] syn = split[1].split(", ");
                        graph.AddVertex(split[0]);
                        for(int i=0; i<syn.length;i++){
                            graph.AddVertex(syn[i]);
                            graph.AddEdge(split[0], syn[i]);
                            for(int j=0;j<syn.length-1;){
                                if(j!=i){
                                    graph.AddEdge(syn[i],syn[j]);
                                    graph.AddEdge(syn[j], split[0]);
                                }
                                j++;
                            }
                        }
                    } 
                    else{
                        graph.AddVertex(split[0]);
                        graph.AddVertex(split[1]);
                        graph.AddEdge(split[0], split[1]);
                    }
                 
                }
            }
            synonyms = new File("SynonymsList5.txt");
            sc= new Scanner(synonyms);
            while(sc.hasNextLine()){
                String line = sc.nextLine();
                if(!line.isBlank()){
                    line=line.toLowerCase();
                    String[] split=line.split("\t");
                        String[] syn = split[1].split(", ");
                        graph.AddVertex(split[0]);
                        for(int i=0; i<syn.length;i++){
                            if(i==syn.length-1 &&syn[i].endsWith(".")){
                                syn[i]=syn[i].substring(0,syn[i].length()-1);
                            }
                            graph.AddVertex(syn[i]);
                            graph.AddEdge(split[0], syn[i]);
                            for(int j=0;j<syn.length-1;){
                                if(j==syn.length-2 &&syn[j].endsWith(".")){
                                syn[j]=syn[j].substring(0,syn[j].length()-1);
                            }
                                if(j!=i){
                                    graph.AddEdge(syn[i],syn[j]);
                                    graph.AddEdge(syn[j], split[0]);
                                }
                                j++;
                            }
                        }
                
            }
            }
            sc.close();
        }catch (FileNotFoundException ex) {
            System.out.println("No file present");
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jList1 = new javax.swing.JList<>();
        jTextField1 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(0, 153, 153));

        jPanel2.setBackground(new java.awt.Color(255, 153, 153));

        jPanel1.setBackground(new java.awt.Color(255, 220, 183));

        jList1.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        jList1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jList1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jList1);

        jTextField1.setFont(new java.awt.Font("Lucida Grande", 0, 10)); // NOI18N
        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });
        jTextField1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTextField1KeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTextField1KeyReleased(evt);
            }
        });

        jButton1.setBackground(new java.awt.Color(255, 153, 153));
        jButton1.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        jButton1.setText("Search");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(117, 117, 117))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 519, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(19, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 6, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jTextField1)
                        .addGap(4, 4, 4)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 364, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10))
        );

        jButton2.setBackground(new java.awt.Color(255, 220, 183));
        jButton2.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        jButton2.setText("Return to Home");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Bodoni 72 Oldstyle", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(102, 102, 102));
        jLabel1.setText("Please insert your word");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(51, 51, 51)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(58, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(246, 246, 246))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 380, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(134, 134, 134))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(34, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextField1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField1KeyReleased
        // TODO add your handling code here:
        //searchfilter(jTextField1.getText());
    }//GEN-LAST:event_jTextField1KeyReleased

    private void jList1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jList1MouseClicked
        // TODO add your handling code here:
        String x= jList1.getSelectedValue();
         findmeaning(x,tree.root);
    }//GEN-LAST:event_jList1MouseClicked

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jTextField1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField1KeyPressed
        // TODO add your handling code here:
        if(evt.getKeyCode()==KeyEvent.VK_ENTER){
           String x =jTextField1.getText();
            
            if  (tree.Find(x,tree.root)==null){
                
                findmeaning(x,tree.root);
            }
            else{
                searchfilter(x);
            }
            
        }
    }//GEN-LAST:event_jTextField1KeyPressed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        NewJFrame jk = new NewJFrame();
        jk.show();
        this.hide();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
           String x =jTextField1.getText();
            
            if  (tree.Find(x,tree.root)==null){
                
                findmeaning(x,tree.root);
            }
            else{
                searchfilter(x);
            }
            
        
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MainPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MainPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MainPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MainPage().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JList<String> jList1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables
}
