/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Synonyms;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author duaqadeer
 */
public class Driver {
    public static void main(String[] args) throws FileNotFoundException{
        SynonymsGraph graph = new SynonymsGraph();
        try{
            File synonyms = new File("SynonymsList1.txt");
            Scanner sc = new Scanner(synonyms);
            while(sc.hasNextLine()){
                String line = sc.nextLine();
                if(!line.isBlank()){
                    line=line.toLowerCase();
                    String[] split=line.split(" — ");  
                        String[] syn = split[1].split(", ");
                        graph.AddVertex(split[0]);
                        for(int i=0; i<syn.length;i++){
                            graph.AddVertex(syn[i]);
                            graph.AddEdge(split[0], syn[i]);
                            for(int j=0;j<syn.length-1;){
                                if(j!=i){
                                    graph.AddEdge(syn[i],syn[j]);
                                    graph.AddEdge(syn[j], split[0]);
                                }
                                j++;
                            }
                        }
                }
            }
        synonyms = new File("SynonymsList2.txt");
        sc= new Scanner(synonyms);
            while(sc.hasNextLine()){
                String line = sc.nextLine();
                if(!line.isBlank()){
                    line=line.toLowerCase();
                    String[] split=line.split(" – ");  
                    if(split[1].contains(",")){
                        String[] syn = split[1].split(", ");
                        graph.AddVertex(split[0]);
                        for(int i=0; i<syn.length;i++){
                            graph.AddVertex(syn[i]);
                            graph.AddEdge(split[0], syn[i]);
                            for(int j=0;j<syn.length-1;){
                                if(j!=i){
                                    graph.AddEdge(syn[i],syn[j]);
                                    graph.AddEdge(syn[j], split[0]);
                                }
                                j++;
                            }
                        }
                    }
                    else{
                        graph.AddVertex(split[0]);
                        graph.AddVertex(split[1]);
                        graph.AddEdge(split[0], split[1]);
                    }
                }
            }
            synonyms = new File("SynonymsList3.txt");
            sc= new Scanner(synonyms);
            while(sc.hasNextLine()){
                String line = sc.nextLine();
                if(!line.isBlank()){
                    line=line.toLowerCase();
                    String[] split=line.split(" . ");  
                    graph.AddVertex(split[0]);
                    graph.AddVertex(split[1]);
                    graph.AddEdge(split[0], split[1]);
                }
            }
            synonyms = new File("SynonymsList4.txt");
            sc= new Scanner(synonyms);
            while(sc.hasNextLine()){
                String line = sc.nextLine();
                if(!line.isBlank()){
                    line=line.toLowerCase();
                    String[] split=line.split(" . ");
                    if(split[1].contains(",")){
                        String[] syn = split[1].split(", ");
                        graph.AddVertex(split[0]);
                        for(int i=0; i<syn.length;i++){
                            graph.AddVertex(syn[i]);
                            graph.AddEdge(split[0], syn[i]);
                            for(int j=0;j<syn.length-1;){
                                if(j!=i){
                                    graph.AddEdge(syn[i],syn[j]);
                                    graph.AddEdge(syn[j], split[0]);
                                }
                                j++;
                            }
                        }
                    } 
                    else{
                        graph.AddVertex(split[0]);
                        graph.AddVertex(split[1]);
                        graph.AddEdge(split[0], split[1]);
                    }
                 
                }
            }
            synonyms = new File("SynonymsList5.txt");
            sc= new Scanner(synonyms);
            while(sc.hasNextLine()){
                String line = sc.nextLine();
                if(!line.isBlank()){
                    line=line.toLowerCase();
                    String[] split=line.split("\t");
                        String[] syn = split[1].split(", ");
                        graph.AddVertex(split[0]);
                        for(int i=0; i<syn.length;i++){
                            if(i==syn.length-1 &&syn[i].endsWith(".")){
                                syn[i]=syn[i].substring(0,syn[i].length()-1);
                            }
                            graph.AddVertex(syn[i]);
                            graph.AddEdge(split[0], syn[i]);
                            for(int j=0;j<syn.length-1;){
                                if(j==syn.length-2 &&syn[j].endsWith(".")){
                                syn[j]=syn[j].substring(0,syn[j].length()-1);
                            }
                                if(j!=i){
                                    graph.AddEdge(syn[i],syn[j]);
                                    graph.AddEdge(syn[j], split[0]);
                                }
                                j++;
                            }
                        }
                
            }
            }
            sc.close();
        }catch (FileNotFoundException ex) {
            System.out.println("No file present");
        }
        System.out.println(graph.count);
        System.out.println(graph.FindVertex("help"));
    }
    
}
