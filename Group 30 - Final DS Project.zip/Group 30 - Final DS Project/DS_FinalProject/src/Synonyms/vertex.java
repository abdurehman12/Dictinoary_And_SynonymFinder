/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Synonyms;

/**
 *
 * @author duaqadeer
 */
public class vertex{
    String word;
    LinkedList synonymslist=new LinkedList();
    vertex(String d){
        word=d;
    }
    @Override
    public String toString(){
        return synonymslist.toString();
    }
}
