/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Synonyms;

/**
 *
 * @author duaqadeer
 */
public class Node {
    vertex v;
    Node next;
    Node(vertex ver){
        v=ver;
    }
    @Override
    public String toString(){
        return v.word;
    }
}

