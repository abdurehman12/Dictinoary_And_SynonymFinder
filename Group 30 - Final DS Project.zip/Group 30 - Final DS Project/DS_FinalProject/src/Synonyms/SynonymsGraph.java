/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Synonyms;

/**
 *
 * @author duaqadeer
 */
public class SynonymsGraph { 
    vertex[] adjList;
    int count;
    public SynonymsGraph(){
        adjList=new vertex[3100];
        count=-1;
    }
    public void AddVertex(String n){ // add person name and age…
        vertex ver = new vertex(n);
        if(count==adjList.length-1){
            System.out.println("List is full");
        }
        else if(FindVertex(n)==null){
            count++; 
            adjList[count]=ver;
        }
        else{
            //System.out.println("Vertex already present in adjacency list");
        }
    }
    public void AddEdge(String n1,String n2) {// add an edge between two person 
        vertex v1 =FindVertex(n1);
        vertex v2 =FindVertex(n2);
        if(v1==null){
            AddVertex(n1);
            v1 =FindVertex(n1);
            
        }
        if(v2==null){
            AddVertex(n2);
            v2=FindVertex(n2);
        }
        if(v1!=null && v2!=null){
            if(v1.synonymslist.find(v2)==false && v2.synonymslist.find(v1)==false){
                v1.synonymslist.Insert(v2);
                v2.synonymslist.Insert(v1);
            }
            else{
            //System.out.println("This relation already exists");                 
            }
        }
        else{
            //System.out.println("Please add the vertices to the list before adding a relation between them"); 
        }
    }
    public void deleteVertex(String n){ // delete a person
        vertex v1= FindVertex(n);
        if(v1!=null){
            for(int i=0;i<=count;i++){
                if(adjList[i].word.equals(n)){
                    adjList[i]=null;
                }
                else{
                        adjList[i].synonymslist.delete(n);
                } 
            }
            AdjustList();
        }
        else{
            //System.out.println("This vertex is not present in list");             
        }
    }
    public void deleteEdge(String n1,String n2){ // delete friend’s relation by removing an edge between two person 
        vertex v1 =FindVertex(n1);
        vertex v2 =FindVertex(n2);
        if(v1!=null && v2!=null){
            v1.synonymslist.delete(n2);
            v2.synonymslist.delete(n1);
        }
        else{
            //System.out.println("Please add the vertices to the list before deleting the relation between them"); 
        }
    }
    public vertex FindVertex(String n){ // find a person 
        for(int i=0; i<=count;i++){
            if(adjList[i].word.equals(n)){
                return adjList[i];
            }
        }
        return null;
    }
    public int FindIndex(String n){ // find a person 
        for(int i=0; i<=count;i++){
            if(adjList[i].word.equals(n)){
                return i;
            }
        }
        return -1;
    }
    @Override
    public String toString(){ // list all person and their friend’s relationship 
        String s="";
        for(int i=0;i<=count;i++){
            s+=adjList[i].synonymslist+"\n";
        }
        return s;
    }

    private void AdjustList(){
        int i=0;
        for(; i<=count;i++){
            if(adjList[i]==null){
                break;
            }
        }
        if(i!=count){
            for(;i<=count-1;i++){
                adjList[i]=adjList[i+1];
            }
        }
        count--;
    }
}


