/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Synonyms;

/**
 *
 * @author duaqadeer
 */
public class LinkedList {
    public Node head;
    public void Insert(vertex v){ // O(n)
        Node n = new Node(v);
        if(head==null){
            head=n;
        }
        else{
            n.next=head.next;
            head.next=n;
        }
    }
    public Boolean find(vertex v){ // O(n)
        Node temp = head;
        while(temp!=null){
            if(temp.v==v){
                return true;
            }
            temp=temp.next;
        }
        return false;
    }
    public void delete(String n){ // O(n)
        if(head!=null){
            Node temp1 = head;
            Node temp2=null;
            if(head.v.word.equalsIgnoreCase(n)){
                head=head.next;
            }
            else{
                while(temp1!=null){
                    if(temp1.v.word.equalsIgnoreCase(n)){
                        break;
                    }
                    temp2=temp1;
                    temp1=temp1.next;
                }
                
                if(temp1!=null){
                    temp2.next=temp1.next;
                }
            }
        }
    }  
    @Override
    public String toString(){ // )(n)
        String s ="";
        Node temp=head;
        while(temp!=null){
            s+=temp+", ";
            temp=temp.next;
        }
        return s;
    }

}
